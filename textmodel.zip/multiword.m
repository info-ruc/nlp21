filename = "factoryReports.csv";
data = readtable(filename,'TextType','String');

textData = data.Description;
textData(1:5)

documents = preprocessText(textData);
documents(1:5)

bag = bagOfNgrams(documents)

figure
wordcloud(bag);
title("Text Data: Preprocessed Bigrams")

mdl = fitlda(bag,10,'Verbose',0);

figure
for i = 1:4
 subplot(2,2,i)
 wordcloud(mdl,i);
 title("LDA Topic " + i)
end

cleanTextData = erasePunctuation(textData);
documents = tokenizedDocument(cleanTextData);

bag = bagOfNgrams(documents,'NGramLengths',3);

figure
wordcloud(bag);
title("Text Data: Trigrams")

tbl = topkngrams(bag,10)

