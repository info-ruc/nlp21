importSize = 50000;

url = "https://export.arxiv.org/oai2?verb=ListRecords" + ...
 "&set=math&metadataPrefix=arXiv";
options = weboptions('Timeout',160);
code = webread(url,options);

tree = htmlTree(code);
subtrees = findElement(tree,"record");
numel(subtrees)

while numel(subtrees) < importSize
  subtreeResumption = findElement(tree,"resumptionToken");
  if isempty(subtreeResumption)
    break
  end
  resumptionToken = extractHTMLText(subtreeResumption);
  url = "https://export.arxiv.org/oai2?verb=ListRecords" + ...
  "&resumptionToken=" + resumptionToken;
  pause(20)
  code = webread(url,options);
  tree = htmlTree(code);
  subtrees = [subtrees; findElement(tree,"record")];
end

subtreesAbstract = htmlTree("");
for i = 1:numel(subtrees)
  subtreesAbstract(i) = findElement(subtrees(i),"abstract");
end

textData = extractHTMLText(subtreesAbstract);

numDocuments = numel(textData);
cvp = cvpartition(numDocuments,'HoldOut',0.1);
textDataTrain = textData(training(cvp));
textDataValidation = textData(test(cvp));

documentsTrain = preprocessText(textDataTrain);
documentsValidation = preprocessText(textDataValidation);

bag = bagOfWords(documentsTrain);
bag = removeInfrequentWords(bag,2);
bag = removeEmptyDocuments(bag);

validationData = bagOfWords(documentsValidation);

numTopics = 40;
solvers = ["cgs" "avb" "cvb0" "savb"];
lineSpecs = ["+-" "*-" "x-" "o-"];

numObservations = bag.NumDocuments;
figure
for i = 1:numel(solvers)
   solver = solvers(i);
   lineSpec = lineSpecs(i);
   if solver == "savb"
      numIterationsPerDataPass = ceil(numObservations/1000);
   else
       numIterationsPerDataPass = 1;
   end
   mdl = fitlda(bag,numTopics, 'Solver',solver, 'InitialTopicConcentration',1, ...
   'FitTopicConcentration',false, 'ValidationData',validationData, ...
   'ValidationFrequency',numIterationsPerDataPass, 'Verbose',0);

   history = mdl.FitInfo.History;
   timeElapsed = history.TimeSinceStart;
   validationPerplexity = history.ValidationPerplexity;
   % Remove NaNs.
   idx = isnan(validationPerplexity);
   timeElapsed(idx) = [];
   validationPerplexity(idx) = [];
   plot(timeElapsed,validationPerplexity,lineSpec)
   hold on
end

hold off
xlabel("Time Elapsed (s)")
ylabel("Validation Perplexity")
ylim([0 inf])
legend(solvers)

load sonnetsCounts.mat
size(counts)

numTopics = 20;
mdl = fitlda(counts,numTopics)

numSamples = 500;
logProbabilities = logp(mdl,counts, ...
 'NumSamples',numSamples);

figure
histogram(logProbabilities)
xlabel("Log Probability")
ylabel("Frequency")
title("Document Log-Probabilities")

