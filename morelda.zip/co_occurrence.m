filename = "weekendUpdates.xlsx";
tbl = readtable(filename,'TextType','string');
textData = tbl.TextData;

textData(1:5)

documents = tokenizedDocument(textData);
documents = lower(documents);
documents = removeStopWords(documents);

bag = bagOfWords(documents);
counts = bag.Counts;

cooccurrence = counts.'*counts;

G = graph(cooccurrence,bag.Vocabulary,'omitselfloops');

LWidths = 5*G.Edges.Weight/max(G.Edges.Weight);

plot(G,'LineWidth',LWidths)
title("Co-occurence Network")

word = "great"

idx = find(bag.Vocabulary == word);
nbrs = neighbors(G,idx);
bag.Vocabulary(nbrs)'

H = subgraph(G,[idx; nbrs]);
LWidths = 5*H.Edges.Weight/max(H.Edges.Weight);
plot(H,'LineWidth',LWidths)
title("Co-occurence Network - Word: """ + word + """");

