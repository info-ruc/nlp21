function textData = financeReports(year,qtr,maxLength)
%%financeReports Download 10-K and 10-Q reports
% textData = financeReports(year,qtr,maxLength) downloads 10-K and 10-Q
% reports for the specified year, quarter, and maximum character length.

% Specify web options.
options = weboptions('ContentType','text','Timeout',10);

% Read master data.
urlMaster = "https://www.sec.gov/Archives/edgar/full-index/" + year + ...
    "/QTR" + qtr + "/master.idx";
data = string(webread(urlMaster,options));
data = splitlines(data);

% Extract form URLs.
idx = contains(data,"10-K") | contains(data,"10-Q");
urls = extractBetween(data(idx),"edgar","txt","Boundaries","inclusive");
urls = "https://www.sec.gov/Archives/" + urls;

% Loop over URLs.
textData = strings(1,numel(urls));
fprintf('Downloading 10-K and 10-Q reports...\n')
tic

parfor i = 1:numel(urls)
    
    % Ignore malformed forms or time outs
    try
        s = string(webread(urls(i),options));
        
        % Do not parse large forms.
        if strlength(s) < maxLength
            textData(i) = extractHTMLText(s);
        end
    end
end

fprintf('Done.\n');
toc

% Remove empty reports.
idx = textData == "";
textData(idx) = [];

% Erase any leftover HTML tags.
textData = eraseTags(textData);

end

