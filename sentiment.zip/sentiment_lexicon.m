year = 2019;
qtr = 4;
maxLength = 2e6;
textData = financeReports(year,qtr,maxLength);

seedsPositive = ["achieve" "advantage" "better" "creative" "efficiency" ...
 "efficiently" "enhance" "greater" "improved" "improving" ...
 "innovation" "innovations" "innovative" "opportunities" "profitable" ...
 "profitably" "strength" "strengthen" "strong" "success"]';

seedsNegative = ["adverse" "adversely" "against" "complaint" "concern" ...
 "damages" "default" "deficiencies" "disclosed" "failure" ...
 "fraud" "impairment" "litigation" "losses" "misleading" ...
 "omit" "restated" "restructuring" "termination" "weaknesses"]';

 documents = preprocessText(textData);

figure
wordcloud(documents);

emb = trainWordEmbedding(documents,'Window',25,'MinCount',20);

numNeighbors = 7;
vocabulary = emb.Vocabulary;
wordVectors = word2vec(emb,vocabulary);
[nearestWords,dist] = vec2word(emb,wordVectors,numNeighbors);

sourceNodes = repelem(vocabulary,numNeighbors);
targetNodes = reshape(nearestWords,1,[]);

edgeWeights = reshape(dist,1,[]);
wordGraph = graph(sourceNodes,targetNodes,edgeWeights,vocabulary);
wordGraph = simplify(wordGraph);

word = "damage";
idx = findnode(wordGraph,word);
nbrs = neighbors(wordGraph,idx);
wordSubgraph = subgraph(wordGraph,[idx; nbrs]);
figure
plot(wordSubgraph)
title("Words connected to """ + word + """")

sentimentScores = zeros([1 numel(vocabulary)]);
maxPathLength = 4;

for depth = 1:maxPathLength
    % Calculate polarity scores.
    polarityPositive = polarityScores(seedsPositive,vocabulary,wordGraph,depth);
    polarityNegative = polarityScores(seedsNegative,vocabulary,wordGraph,depth);
    % Account for difference in overall mass of positive and negative flow in the graph.
    b = sum(polarityPositive) / sum(polarityNegative);
    % Calculate new sentiment scores.
    sentimentScoresNew = polarityPositive - b * polarityNegative;
    sentimentScoresNew = normalize(sentimentScoresNew,'range',[-1,1]);
    % Add scores to sum.
    sentimentScores = sentimentScores + sentimentScoresNew;
end

sentimentScores = sentimentScores / maxPathLength;

tbl = table;
tbl.Token = vocabulary';
tbl.SentimentScore = sentimentScores';

thr = 0.1;
idx = abs(tbl.SentimentScore) < thr;
tbl(idx,:) = [];

tbl = sortrows(tbl,'SentimentScore','descend');

figure
subplot(1,2,1);
idx = tbl.SentimentScore > 0;
tblPositive = tbl(idx,:);
wordcloud(tblTopPositive,'Token','SentimentScore')
title('Positive Words')
subplot(1,2,2);
idx = tbl.SentimentScore < 0;
tblNegative = tbl(idx,:);
tblNegative.SentimentScore = abs(tblNegative.SentimentScore);
wordcloud(tblTopNegative,'Token','SentimentScore')
title('Negative Words')

filename = "financeSentimentLexicon.csv";
writetable(tbl,filename)

textDataNew = [
 "This company is showing extremely strong growth."
 "This other company is accused of misleading consumers."];
documentsNew = preprocessText(textDataNew);

compoundScores = vaderSentimentScores(documentsNew,'SentimentLexicon',tbl)

