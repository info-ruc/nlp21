sentence(VP) --> noun_phrase(Actor), verb_phrase(Actor,VP).
noun_phrase(NP) --> proper_noun(NP).
verb_phrase(Actor,VP) --> intrans_verb(Actor,VP).
verb_phrase(Actor,VP) --> trans_verb(Actor,Y,VP),				       noun_phrase(Y).
intrans_verb(Actor, paints(Actor)) --> [paints].
trans_verb(X,Y, likes(X,Y)) --> [likes].
proper_noun(john) --> [john].
proper_noun(annie) --> [annie].

