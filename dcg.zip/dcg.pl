%
%%	Example that accepts simple sentences using dcg
%

sentence --> subject, verb, predicate.
sentence --> subject, verb.

subject --> noun.
subject --> adjective, subject.

adjective --> [tall].
adjective --> [short].
adjective --> [a], adjective.

verb --> [runs].
verb --> [lies].

predicate --> [quickly].
predicate --> [quietly].

noun --> [grass].
noun --> [tree].
noun --> [field].
noun --> [sun].

poem(Poem) :-
	phrase(sentence , Poem).


paper -->  title, abstract, intro, method, experiment, conclusion.
title --> title1.
title --> title2.
title --> title3.
abstract --> [abstract], [section].
intro --> [intro], [section].
method --> [method], [section].
experiment --> [experiment], [section].
conclusion --> [conclusion], [section].

title1 --> ["Distilling the knowledge in a neural network"].
title2 --> ["Deep neural networks are easily fooled: High confidence predictions for unrecognizable images"].
title3 --> ["How transferable are features in deep neural networks? "].







